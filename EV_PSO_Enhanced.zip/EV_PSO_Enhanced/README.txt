Enhanced PSO for EV Charging Station Placement (MATLAB)
-------------------------------------------------
This improved version includes:
- Multi-objective fitness (EV demand + energy + geographic spread)
- Dynamic inertia weight (better convergence)
- Automatic saving of selected sites to CSV
- Convergence plot visualization

To run:
1. Unzip the folder.
2. Open MATLAB and set this folder as the working directory.
3. Run: pso_ev_selection
