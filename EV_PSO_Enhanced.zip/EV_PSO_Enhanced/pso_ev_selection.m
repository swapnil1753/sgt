clc; clear; close all;
disp('🚗 Running Enhanced PSO for EV Station Placement...');

% Load dataset
data = readtable('CityX_SmartGrid_Dataset.csv');

% Parameters
num_sites = height(data);
num_selected = 20;

% PSO parameters
n_particles = 40;
max_iter = 150;
w_max = 0.9; w_min = 0.4;
c1 = 1.8; c2 = 1.8;

% Initialize particles
particles = zeros(n_particles, num_sites);
for i = 1:n_particles
    idx = randperm(num_sites, num_selected);
    particles(i, idx) = 1;
end
velocities = zeros(n_particles, num_sites);
pbest = particles;
pbest_values = zeros(n_particles, 1);

for i = 1:n_particles
    pbest_values(i) = fitness_function(particles(i,:), data, num_selected);
end

[best_value, idx_best] = max(pbest_values);
gbest = pbest(idx_best, :);
best_curve = zeros(max_iter, 1);

% Main PSO loop
for iter = 1:max_iter
    w = w_max - ((w_max - w_min) * iter / max_iter);
    for i = 1:n_particles
        r1 = rand(1, num_sites);
        r2 = rand(1, num_sites);
        velocities(i,:) = w*velocities(i,:) + c1*r1.*(pbest(i,:)-particles(i,:)) + c2*r2.*(gbest-particles(i,:));
        probabilities = 1./(1+exp(-velocities(i,:)));
        particles(i,:) = double(rand(1, num_sites) < probabilities);
        
        % Ensure exactly num_selected sites
        [~, idx_sort] = sort(rand(1, num_sites), 'descend');
        particles(i,:) = 0;
        particles(i, idx_sort(1:num_selected)) = 1;
        
        % Evaluate
        fit_val = fitness_function(particles(i,:), data, num_selected);
        if fit_val > pbest_values(i)
            pbest(i,:) = particles(i,:);
            pbest_values(i) = fit_val;
        end
    end
    
    [curr_best, idx_best] = max(pbest_values);
    if curr_best > best_value
        best_value = curr_best;
        gbest = pbest(idx_best, :);
    end
    
    best_curve(iter) = best_value;
    fprintf('Iteration %d/%d -> Best Value = %.2f\n', iter, max_iter, best_value);
end

best_sites = find(gbest == 1);

% Results
disp('✅ Selected Site IDs:');
disp(data.Site_ID(best_sites));
disp(['Total Fitness Score = ', num2str(best_value)]);

% Save selected sites to CSV
selected_sites = data(best_sites, :);
writetable(selected_sites, 'Selected_Sites.csv');
disp('💾 Selected site data saved to Selected_Sites.csv');

% Plot results
figure;
geoscatter(data.Latitude, data.Longitude, 40, 'b', 'filled');
hold on;
geoscatter(data.Latitude(best_sites), data.Longitude(best_sites), 80, 'r', 'filled');
geobasemap streets;
legend('All Sites', 'Selected Sites');
title('Enhanced PSO - Optimal EV Station Locations (20 Sites)');

% Plot convergence curve
figure;
plot(1:max_iter, best_curve, 'LineWidth', 2);
xlabel('Iteration'); ylabel('Fitness Value');
title('PSO Convergence Curve');
grid on;
