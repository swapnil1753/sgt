function val = fitness_function(selection, data, num_selected)
if sum(selection) ~= num_selected
    val = -inf;
else
    % Demand score
    demand_score = sum(data.Total_EVs(logical(selection)));
    % Energy score
    energy_score = sum(data.Daily_Energy_kWh(logical(selection)));
    % Geographic spread (mean pairwise distance)
    lat = data.Latitude(logical(selection));
    lon = data.Longitude(logical(selection));
    if length(lat) > 1
        dist_matrix = pdist2([lat lon], [lat lon]);
        avg_dist = mean(dist_matrix(:));
    else
        avg_dist = 0;
    end
    
    % Weighted fitness (normalize components)
    val = 0.5 * demand_score + 0.4 * energy_score + 0.1 * avg_dist;
end
end
